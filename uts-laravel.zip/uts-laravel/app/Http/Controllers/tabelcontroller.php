<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Http\Request;

class tabelcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view("tabel.index", [
            'data'=>Barang::all()
        ] );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tabel.input', [
            'datasatuan' =>Satuan::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'kodebarang'=>'required',
            'namabarang'=>'required',
            'hargabarang'=>'required|numeric',
            'deskripsi'=>'required',
        ]);
        $barang=New Barang;
        $barang->kodebarang =$request->kodebarang;
        $barang->namabarang = $request->namabarang;
        $barang->hargabarang = $request->hargabarang;
        $barang->deskripsi = $request->deskripsi;
        $barang->satuan_id = $request->satuanbarang;
        $barang->save();

        return redirect()->route('tabel.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('tabel.edit', [
            'databarang'=> Barang::find($id),
            'datasatuan' => Satuan::all()

        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([

            'namabarang'=>'required',
            'hargabarang'=>'required|numeric',
            'deskripsi'=>'required',
        ]);
        $barang= Barang::find($id);

        $barang->namabarang = $request->namabarang;
        $barang->hargabarang = $request->hargabarang;
        $barang->deskripsi = $request->deskripsi;
        $barang->satuan_id = $request->satuanbarang;
        $barang->save();

        return redirect()->route('tabel.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Barang::find($id)->delete();
        return redirect()->route('tabel.index');
    }
}
