<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAQQI</title>
    <link rel="shortcut icon" href="<?php echo e(asset ('img/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<body>
    <!-- Navbar -->

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm fixed-top" style="background-color: #000">

        <div class="container-fluid">

            <a href="#" class="navbar-brand mb-0 h1">
                <img src="<?php echo e(asset ('img/logo.png')); ?>" alt="logo" style="width: 40px;">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('about')); ?>">About Me</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Barang
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="<?php echo e(route('tabel.index')); ?>">List Barang</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('tabel.create')); ?>">Input Barang</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="https://github.com/Zynthink">Github <i class="bi bi-github"></i></a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-light" type="submit">Search</button>
            </form>
          </div>
        </div>
      </nav>

    <!-- Main -->
<?php echo $__env->yieldContent('kontensaya'); ?>
    <!-- Footer -->

    <div class="footer">
        <footer class="text-white text-center text-lg-start bg-dark">
        <div class="container p-4">

            <div class="row mt-4">
            <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4">About me</h5>

                <p>
                Saya adalah seorang Lorem ipsum dolor sit, amet consectetur adipisicing elit. Rem vel, quae illo at quam illum nam et delectus esse harum maiores, deleniti sit laboriosam quidem labore. Aliquid perspiciatis quo impedit!
                </p>

                <div class="mt-4">
                <a type="button" class="btn btn-floating btn-light btn-lg" href="https://www.instagram.com/iqbaltawwaqal22/?hl=id"><i class="bi bi-instagram"></i></a>
                <a type="button" class="btn btn-floating btn-light btn-lg" href="https://www.facebook.com/iqbal.tawwaqal.1/" ><i class="bi bi-facebook"></i></a>
                <a type="button" class="btn btn-floating btn-light btn-lg" href="https://mail.google.com/mail/?view=cm&fs=1&to=muhammad22hamid@gmail.com&su=Subject&body=Body" ><i class="bi bi-google"></i></a>
                <a type="button" class="btn btn-floating btn-light btn-lg" href="https://drive.google.com/file/d/1fe0nxtC7xgqOfVew_vRg_33iMDaRIpKV/view?usp=sharing" ><i class="bi bi-download"></i></a>

                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4 mb-md-0">

                <ul class="fa-ul" style="margin-left: 1.65em;">
                <li class="mb-3">
                    <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">Surabaya, 22-11-2021 , Indonesia</span>
                </li>
                <li class="mb-3">
                    <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">muhammad22hamid@gmail.com</span>
                </li>
                <li class="mb-3">
                    <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">+ 62 0877 000 000</span>
                </li>
                </ul>
            </div>

            <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4">Work Schedule</h5>

                <table class="table text-center text-white">
                <tbody class="fw-normal">
                    <tr>
                    <td>Mon - Thu :</td>
                    <td>8am - 3pm</td>
                    </tr>
                    <tr>
                    <td>Fri - Sat :</td>
                    <td>8am - 11am</td>
                    </tr>
                    <tr>
                    <td>Sunday :</td>
                    <td>Holiday</td>
                    </tr>
                </tbody>
                </table>
            </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            Copyright © Batman
        </div>
        </footer>
    </div>
    <script src="<?php echo e(asset ('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/taqqi/Documents/aplication/uts-laravel/resources/views/main.blade.php ENDPATH**/ ?>