<?php $__env->startSection('kontensaya'); ?>

      <!-- Gelombang -->
      <section>
          <div class="gelombang pt-5">
          </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120"><path fill="#B7B7B7" fill-opacity="1" d="M0,32L60,53.3C120,75,240,117,360,117.3C480,117,600,75,720,58.7C840,43,960,53,1080,53.3C1200,53,1320,43,1380,37.3L1440,32L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z"></path></svg>
      </section>

    <!-- Main -->
    <div class="table">
        <div class="container">
            <div class="row">
                <div class="col-mid">
                    <h2 class="text-uppercase text-center fw-bold"> Data Barang</h2>
                </div>
                <hr>
            </div>
            <div class="row">
                <div class="col-md">
                    <a href="<?php echo e(route('tabel.create')); ?>" class="btn btn-dark"><i class="bi bi-folder-plus"></i> Tambah Data Barang </a>
                </div>
            </div>

        <div class="row my-5">
            <div class="col-md">
                <table id="tabelbarang" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Harga Barang</th>
                            <th>Deskripsi</th>
                            <th>Satuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td> <?php echo e($barang->kodebarang); ?> </td>
                                <td> <?php echo e($barang->namabarang); ?> </td>
                                <td> <?php echo e($barang->hargabarang); ?> </td>
                                <td> <?php echo e($barang->deskripsi); ?> </td>
                                <td> <?php echo e($barang->satuan->nama_satuan); ?> </td>
                                <td>
                                    <div>
                                        <a href="<?php echo e(route ('tabel.edit', [$barang->id])); ?>">Edit</a>
                                        <div>
                                            <form action="<?php echo e(route ('tabel.destroy', [$barang->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>



    <section>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#B7B7B7" fill-opacity="1" d="M0,96L30,96C60,96,120,96,180,128C240,160,300,224,360,234.7C420,245,480,203,540,202.7C600,203,660,245,720,266.7C780,288,840,288,900,261.3C960,235,1020,181,1080,176C1140,171,1200,213,1260,208C1320,203,1380,149,1410,122.7L1440,96L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>
    </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\uts-laravel\resources\views/tabel/index.blade.php ENDPATH**/ ?>