<?php $__env->startSection('kontensaya'); ?>


    <!-- Main -->
    <section class="data" id="data">
        <h1 class="heading"><span> About </span> Me </h1>
        <center><img src="<?php echo e(asset ('img/iqbal.jpg')); ?>" alt="user" width="200px" class="rounded-circle img-thumbnail"> </center>
        <div class="row">
        <div class="info">
            <h3> <span> nama : </span> Iqba Tawwaqal</h3>
            <h3> <span> age : </span> 20 </h3>
            <h3> <span> address : </span> Jl. Sepanjang jalan </h3>
            <h3> <span> date of birth : </span> 22 . 11 . 2000 </h3>
            <h3> <span> country : </span> Indonesia  </h3>
            <h3> <span> hobby : </span>
                <p><i class="bi bi-controller"></i> game </p>
                <p><i class="bi bi-book"></i> comic </p>
                <p><i class="bi bi-code"></i> code </p>
            </h3>
        </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#B7B7B7" fill-opacity="1" d="M0,96L30,96C60,96,120,96,180,128C240,160,300,224,360,234.7C420,245,480,203,540,202.7C600,203,660,245,720,266.7C780,288,840,288,900,261.3C960,235,1020,181,1080,176C1140,171,1200,213,1260,208C1320,203,1380,149,1410,122.7L1440,96L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>
    </section>

    <!-- Intro -->

    <section id="intro">
        <div class="introcontent">
            <div class="container">
                <div class="row text-center mb-3">
                    <div class="col">
                        <h2>Introduction</h2>
                    </div>
                </div>
                <div class="row justify-content-center fs-5 text-center">
                    <div class="col-md-4">
                        <p>ipsum dolor sit amet consectetur adipisicing elit. Iure, nam laborum distinctio expedita numquam asperiores illo alias? Ipsum expedita sed, et perspiciatis dolores officia praesentium a velit eligendi aperiam voluptate!</p>
                    </div>
                    <div class="col-md-4">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe vitae repellendus ipsa eaque et, expedita dolorum quisquam ratione sint optio omnis quos hic exercitationem, quaerat non, quod provident dolore enim.</p>
                    </div>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 180"><path fill="#B7B7B7" fill-opacity="1" d="M0,32L60,53.3C120,75,240,117,360,117.3C480,117,600,75,720,58.7C840,43,960,53,1080,53.3C1200,53,1320,43,1380,37.3L1440,32L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z"></path></svg>
    </section>

    <!-- Video -->

    <section id="video">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <h2>My Video Motion Graphics</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-12 mb-3">
                    <div class="card">
                        <iframe src="https://www.youtube.com/embed/uF96guoTTc0" frameborder="0"></iframe>
                        <div class="card-body">
                          <p class="card-text">Motion Eid Mubarak</p>
                        </div>
                      </div>
                </div>

                <div class="col-md-4 col-sm-12 mb-3">
                    <div class="card">
                        <iframe src="https://www.youtube.com/embed/0GH-ptQ7pLY" frameborder="0"></iframe>
                        <div class="card-body">
                          <p class="card-text">M Animation Bumper</p>
                        </div>
                      </div>
                </div>

                <div class="col-md-4 col-sm-12 mb-3">
                    <div class="card">
                        <iframe src="https://www.youtube.com/embed/rq2MNVTAztI" frameborder="0"></iframe>
                        <div class="card-body">
                          <p class="card-text">Slide Simple Motion Graphics</p>
                        </div>
                      </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card">
                        <iframe src="https://www.youtube.com/embed/ONtjwZoTMbc" frameborder="0"></iframe>
                        <div class="card-body">
                          <p class="card-text">What Information System ? What a job ?</p>
                        </div>
                      </div>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#B7B7B7" fill-opacity="1" d="M0,96L30,96C60,96,120,96,180,128C240,160,300,224,360,234.7C420,245,480,203,540,202.7C600,203,660,245,720,266.7C780,288,840,288,900,261.3C960,235,1020,181,1080,176C1140,171,1200,213,1260,208C1320,203,1380,149,1410,122.7L1440,96L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>
    </section>

    <!-- Footer -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/taqqi/Documents/aplication/uts-laravel/resources/views/aboutme.blade.php ENDPATH**/ ?>