@extends('main')
@section('kontensaya')


<main class="container " style="height: 650px; padding-top:70px">
    <form  method="post" action="{{route ('tabel.update', [$databarang->id])}}">
        @csrf
        @method('put')
        <div class="row g-3 pt-5">
            <div class="col-md-6">
                <input class="form-control @error('kodebarang') is-invalid @enderror" placeholder="Kode Barang" type="text" name="kodebarang" value="{{$databarang->kodebarang}}" disabled>
                @error('kodebarang')
                    {{$message}}
                @enderror
            </div>

            <div class="col-md-6">
                <input class="form-control @error('namabarang') is-invalid @enderror" placeholder="Nama Barang" type="text" name="namabarang" value="{{$databarang->namabarang}}">
                @error('namabarang')
                    {{$message}}
                @enderror
            </div>

            <div class="col-md-6">
                <input class="form-control @error('hargabarang') is-invalid @enderror" placeholder="Harga Barang" type="text" name="hargabarang" value="{{$databarang->hargabarang}}">
                @error('hargabarang')
                    {{$message}}
                @enderror
            </div>

            <div class="col-md-6">
                <input class="form-control @error('deskripsi') is-invalid @enderror" placeholder="Deskripsi Barang" type="text" name="deskripsi" value="{{$databarang->deskripsi}}">
                @error('deskripsi')
                    {{$message}}
                @enderror
            </div>

            <div class="col-md-6">
                <select class="form-select"  name="satuanbarang" id="jumlah" >
                    @foreach ($datasatuan as $satuan)
                    <option value="{{$satuan->id}}" {{ $databarang->satuan_id == $satuan->id ? 'selected' : '' }} >{{$satuan->id}} {{$satuan->nama_satuan}} </option>

                    @endforeach
                </select>
            </div>

            <div class="col-md-6">
                <button type="submit" class="btn btn-primary btn-lg w-100">Submit</button>
            </div>

        </div>

    </form>
</main>


@endsection

