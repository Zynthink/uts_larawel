@extends('main')
@section('kontensaya')

<!-- Main -->


    <section class="jumbotron text-center">
        <img src="{{asset ('img/iqbal.jpg')}}" alt="user" width="200px" class="rounded-circle img-thumbnail">
        <h1 class="display-4">Hello, I am Iqbal Tawwaqal</h1>
        <p class="lead">Freelance | Motion Graphics </p>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#B7B7B7" fill-opacity="1" d="M0,96L30,96C60,96,120,96,180,128C240,160,300,224,360,234.7C420,245,480,203,540,202.7C600,203,660,245,720,266.7C780,288,840,288,900,261.3C960,235,1020,181,1080,176C1140,171,1200,213,1260,208C1320,203,1380,149,1410,122.7L1440,96L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>
    </section>

    <section>
        <div class="conten" >
            <div class="container py-5 px-4 ">
                <div class="row">
                    <div class="col-md-5 order-md-2">
                        <img src="{{asset ('img/motion.jpeg')}}" alt="main conten" >
                    </div>
                    <div class="col-md-7 order-md-1 text-center">
                        <h2 class="mt-4"> Motion Graphics </h2>
                        <p class="mt-3"> Secara umum, motion graphic merupakan gabungan dari media visual yang menggabungkan bahasa film dengan desain grafis.
                                         Hal tersebut dilakukan dengan memasukkan elemen-elemen lainnya seperti 3D, 2D, ilustrasi, animasi, tipografi, fotografi, video, dan musik.</p>
                        <div class="row text-center mb-4">
                            <div class="d-flex flex-column flex-md-wrap">
                                <a href="https://helpx.adobe.com/sea/support/after-effects.html?promoid=RBS7NR3C&mv=other"><button type="button" class="btn btn-outline-dark btn-lg mb-3 me-md-3"> Learn <i class="bi bi-bookmarks-fill"></i></button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 180"><path fill="#B7B7B7" fill-opacity="1" d="M0,32L60,53.3C120,75,240,117,360,117.3C480,117,600,75,720,58.7C840,43,960,53,1080,53.3C1200,53,1320,43,1380,37.3L1440,32L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z"></path></svg>
    </section>

    <!-- Design -->

    <section id="design">
        <div class="container">
            <div class="row text-center mb-3">
                <div class="col">
                    <h2>My Design</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3 col-sm-12 ">
                    <div class="card">
                        <img src="{{asset ('img/Artboard 2.png')}}" class="card-img-top" alt="covid">
                        <div class="card-body">
                          <p class="card-text">Ini adalah design data covid yang terjadi di Indonesia.</p>
                        </div>
                      </div>
                </div>


                <div class="col-md-4 mb-3 col-sm-12">
                    <div class="card">
                        <img src="{{asset ('img/zul.png')}}" class="card-img-top" alt="sertif">
                        <div class="card-body">
                          <p class="card-text">Sertif dibuat untuk UKKI.</p>
                        </div>
                      </div>
                </div>


                <div class="col-md-4 mb-3 col-sm-12">
                    <div class="card">
                        <img src="{{asset ('img/iq1.png')}}" class="card-img-top" alt="card">
                        <div class="card-body">
                          <p class="card-text">Card name, dibuat pada matkul PKWU. Design di buat dengan menggunakan adobe illustrator.</p>
                        </div>
                      </div>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 320"><path fill="#B7B7B7" fill-opacity="1" d="M0,96L30,96C60,96,120,96,180,128C240,160,300,224,360,234.7C420,245,480,203,540,202.7C600,203,660,245,720,266.7C780,288,840,288,900,261.3C960,235,1020,181,1080,176C1140,171,1200,213,1260,208C1320,203,1380,149,1410,122.7L1440,96L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>
    </section>

    <section id="about">
        <div class="container">
            <div class="row text-center mb-4">
                <div class="col">
                    <h2>About Me</h2>
                </div>
            </div>
            <div class="row justify-content-center fs-5 text-center">
                <div class="col-md-4">
                    <p>ipsum dolor sit amet consectetur adipisicing elit. Iure, nam laborum distinctio expedita numquam asperiores illo alias? Ipsum expedita sed, et perspiciatis dolores officia praesentium a velit eligendi aperiam voluptate!</p>
                </div>
                <div class="col-md-4">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe vitae repellendus ipsa eaque et, expedita dolorum quisquam ratione sint optio omnis quos hic exercitationem, quaerat non, quod provident dolore enim.</p>
                </div>
            </div>
        </div>
    </section>

@endsection
