<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SatuanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        DB::table('satuans')->insert([
            'kodesatuan'=> 'meter',
            'nama_satuan' => 'pck'

        ]);

        DB::table('satuans')->insert([
            'kodesatuan'=> 'cm',
            'nama_satuan' => 'kg'
        ]);

        DB::table('satuans')->insert([
            'kodesatuan'=> 'km',
            'nama_satuan' => 'unit'
        ]);

    }
}
