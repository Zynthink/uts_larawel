<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('barangs')->insert([
            'kodebarang' => 'kode',
            'namabarang' => 'nama',
            'hargabarang' => 20000,
            'deskripsi' => 'informasi barang',
            'satuan_id' => 1,
        ]);

        DB::table('barangs')->insert([
            'kodebarang' => 'kodebarang',
            'namabarang' => 'nama',
            'hargabarang' => 20000,
            'deskripsi' => 'informasi barang',
            'satuan_id' => 2,
        ]);

        DB::table('barangs')->insert([
            'kodebarang' => 'kd',
            'namabarang' => 'nama',
            'hargabarang' => 20000,
            'deskripsi' => 'informasi barang',
            'satuan_id' => 3,
        ]);
    }
}
